<?php

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    $opt_name = "pink";


    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'opt_name'             => $opt_name,
        'display_name'         => $theme->get( 'Name' ),
        'display_version'      => $theme->get( 'Version' ),
        'menu_type'            => 'menu',
        'allow_sub_menu'       => true,
        'menu_title'           => __( 'Pink Options', 'redux-framework-demo' ),
        'page_title'           => __( 'Pink Options', 'redux-framework-demo' ),
        'google_api_key'       => '',
        'google_update_weekly' => false,
        'async_typography'     => true,
        'admin_bar'            => true,
        'admin_bar_icon'       => 'dashicons-carrot',
        'menu_icon'            => 'dashicons-carrot',
        'page_priority'        => 1,
        'admin_bar_priority'   => 50,
        'global_variable'      => '',
        'dev_mode'             => false,
        'update_notice'        => false,
        'customizer'           => true,
        'page_parent'          => 'themes.php',
        'page_permissions'     => 'manage_options',
        'last_tab'             => '',
        'page_icon'            => 'icon-themes',
        'page_slug'            => '_options',
        'save_defaults'        => true,
        'default_show'         => false,
        'default_mark'         => '',
        'show_import_export'   => true,
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        'output_tag'           => true,
        'database'             => '',
        'use_cdn'              => true,
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'light',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );



    // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
    $args['share_icons'][] = array(
        'url'   => 'https://github.com/mortuzahossain/',
        'title' => 'Get more free theme on GitHub',
        'icon'  => 'el el-github'
    );
    $args['share_icons'][] = array(
        'url'   => 'https://www.facebook.com/pages/Redux-Framework/243141545850368',
        'title' => 'Be friend of mine on Facebook',
        'icon'  => 'el el-facebook'
    );

    Redux::setArgs( $opt_name, $args );



    // For General Setting
    Redux::setSection( $opt_name, array(
        'title'            => __( 'General Settings', 'redux-framework-demo' ),
        'id'               => 'basic',
        'icon'             => 'el el-home',
        'fields'           => array(
            array(
                'id'       => 'upload-facivon',
                'type'     => 'switch',
                'title'    => 'Upload Favicon',
                'default'  => false
            ),
            array(
                'id'        => 'favicon',
                'type'      => 'media',
                'title'     => __( 'Favicon Icon', 'redux-framework-demo' ),
                'required' => array( 'upload-facivon', '=', true )
            ),
            array(
                'id'        => 'copyright-text',
                'type'      => 'text',
                'title'     => __( 'Copyright Text', 'redux-framework-demo' ),
                'default'   => 'Copyright 2016 © by XS@mail.com'
            ),
        )
    ) );


    // For Other Menus

    // For Navigation bar and Shorted section
    Redux::setSection( $opt_name, array(
        'title'            => __( 'Menu Setting', 'redux-framework-demo' ),
        'id'               => 'nav',
        'desc'    => 'Drag menu item in order to show Menu item as the order item order.',
        'icon'             => 'el el-cog-alt',
        'fields'           => array(
            array(
                'id'      => 'nav-item',
                'type'    => 'sorter',
                'options' => array(
                    'enabled'  => array(
                        'whatido'   => 'What I Do',
                        'myworks' => 'My Works',
                        'about'     => 'About Me',
                        'contact'   => 'Contact'
                    ),
                    'disabled' => array(
                    )
                ),
            ),      
            array(
                'id'          => 'home-slider',
                'type'        => 'slides',
                'title'       => __('Add Slider', 'redux-framework-demo'),
                'subtitle'        => __('Please add at list one slide. Otherwise it will looks broken.', 'redux-framework-demo'),
                'placeholder' => array(
                    'title'           => __('Slide Title', 'redux-framework-demo'),
                    'description'     => __('Slide Button Text', 'redux-framework-demo'),
                    'url'             => __('Slide Button URL', 'redux-framework-demo'),
                ),
            ),
        )
    ) );

    // For What I DO section
    


    //For about me section
    Redux::setSection( $opt_name, array(
        'title'            => __( 'About Me', 'redux-framework-demo' ),
        'id'               => 'about',
        'icon'             => 'el el-adult',
        'fields'           => array(
            array(
                'id'        => 'about-header-text',
                'type'      => 'text',
                'title'     => __( 'About Header', 'redux-framework-demo' ),
                'default'   => 'About me'
            ),
            array(
                'id'       => 'about-head_title_rigth',
                'type'     => 'textarea',
                'title'    => __( 'About Header Title Right', 'redux-framework-demo' ),
                'default'  => 'Fingerstache green juice semiotics quinoa, truffaut letterpress wolf photo booth ugh biodiesel mumblecore brunch. Meh austin vinyl banh mi, gluten-free chillwave scenester kombucha street art. Before they sold out lumbersexual chillwave, cold-pressed mumblecore beard pickled letterpress normcore crucifix.',
            ), 
            array(
                'id'          => 'main_about_content',
                'type'        => 'slides',
                'title'       => __('About Content', 'redux-framework-demo'),
                'placeholder' => array(
                    'title'           => __('Title', 'redux-framework-demo'),
                    'description'     => __('Description', 'redux-framework-demo'),
                    'url'             => __('Count', 'redux-framework-demo'),
                )
            ),
        )
    ) );


    //For What I do section
    Redux::setSection( $opt_name, array(
        'title'            => __( 'What I Do', 'redux-framework-demo' ),
        'id'               => 'whatido',
        'icon'             => 'el el-idea-alt ',
        'fields'           => array(
            array(
                'id'        => 'whatido-header-text',
                'type'      => 'text',
                'title'     => __( 'What I Do Header', 'redux-framework-demo' ),
                'default'   => 'What I Do'
            ),
            array(
                'id'       => 'whatido-head_title_rigth',
                'type'     => 'textarea',
                'title'    => __( 'What I Do Header Title Right', 'redux-framework-demo' ),
                'default'  => 'Fingerstache green juice semiotics quinoa, truffaut letterpress wolf photo booth ugh biodiesel mumblecore brunch. Meh austin vinyl banh mi, gluten-free chillwave scenester kombucha street art. Before they sold out lumbersexual chillwave, cold-pressed mumblecore beard pickled letterpress normcore crucifix.',
            ), 
            array(
                'id'          => 'main_whatido_content',
                'type'        => 'slides',
                'title'       => __('About Content', 'redux-framework-demo'),
                'placeholder' => array(
                    'title'           => __('Title', 'redux-framework-demo'),
                    'description'     => __('Description', 'redux-framework-demo'),
                    'url'             => __('Count', 'redux-framework-demo'),
                ),
                'show' => array(
                     'title' => true,
                     'description' => true,
                     'url' => false
                ),
            ),
        )
    ) );
    //For My Work section
    Redux::setSection( $opt_name, array(
        'title'            => __( 'My Work', 'redux-framework-demo' ),
        'id'               => 'myworks',
        'icon'             => 'el el-wheelchair',
        'fields'           => array(
            array(
                'id'        => 'myworks-header-text',
                'type'      => 'text',
                'title'     => __( 'My Works', 'redux-framework-demo' ),
                'default'   => 'My Works'
            ),
            array(
                'id'          => 'myworks_image_upload',
                'type'        => 'slides',
                'title'       => __('My Works Image', 'redux-framework-demo'),
                'placeholder' => array(
                    'title'           => __('Alternative Text For The Image (Optional)', 'redux-framework-demo')
                ),
                'show' => array(
                     'title' => true,
                     'description' => false,
                     'url' => false
                ),
            ),
        )
    ) );
    //For Contact Me section 'required' => array( 'upload-facivon', '=', true )
    Redux::setSection( $opt_name, array(
        'title'            => __( 'Contact', 'redux-framework-demo' ),
        'id'               => 'contact',
        'icon'             => 'el el-comment-alt',
        'fields'           => array(
            array(
                'id'        => 'contact-header-text',
                'type'      => 'text',
                'title'     => __( 'Contact Header', 'redux-framework-demo' ),
                'default'   => 'GET IN TOUCH'
            ),
            array(
                'id'       => 'admin-email',
                'type'     => 'text',
                'title'    => __('Admin Email', 'redux-framework-demo'),
                'subtitle' => __('Fill the email address where you want to receive the email.', 'redux-framework-demo'),
                'validate' => 'email',
                'msg'      => 'Please Provide Real Email Address',
                'default'  => get_option( 'admin_email' )
            ),
            array(
                'id'          => 'contact-social-icon',
                'type'        => 'slides',
                'title'       => __('Contact Social Icon', 'redux-framework-demo'),
                'placeholder' => array(
                    'title'           => __('Social link with http://', 'redux-framework-demo')
                ),
                'show' => array(
                     'title' => true,
                     'description' => false,
                     'url' => false
                ),
            ),

            array(
                'id'       => 'contact_adress-enable',
                'type'     => 'switch',
                'title'    => 'Enable Address',
                'default'  => false
            ),
            array(
                'id'        => 'contact-address-header',
                'type'      => 'text',
                'title'     => __( 'Address Header', 'redux-framework-demo' ),
                'default'   => 'Address:',
                'required' => array( 'contact_adress-enable', '=', true )
            ),
            array(
                'id'               => 'contact-editor-text',
                'type'             => 'editor',
                'title'            => __('Contact Address', 'redux-framework-demo'), 
                'default'          => '
                                <span>9114 Bridge Street ,</span>
                                <span>Hillsboro, OR 97124</span>',
                'args'   => array(
                    'teeny'            => false,
                    'textarea_rows'    => 5
                ),
                'required' => array( 'contact_adress-enable', '=', true )
            ),

            array(
                'id'       => 'contact_phone-enable',
                'type'     => 'switch',
                'title'    => 'Enable Phone',
                'default'  => false
            ),
            array(
                'id'        => 'contact-phone-header',
                'type'      => 'text',
                'title'     => __( 'Phone Header', 'redux-framework-demo' ),
                'default'   => 'Phone:',
                'required' => array( 'contact_phone-enable', '=', true )
            ),
            array(
                'id'        => 'contact-phone-number',
                'type'      => 'text',
                'title'     => __( 'Phone Number', 'redux-framework-demo' ),
                'default'   => '+48 202 - 555 - 0114',
                'required' => array( 'contact_phone-enable', '=', true )
            ),
            
            array(
                'id'       => 'contact_email-enable',
                'type'     => 'switch',
                'title'    => 'Enable Email',
                'default'  => false
            ),
            array(
                'id'        => 'contact-email-header',
                'type'      => 'text',
                'title'     => __( 'Email', 'redux-framework-demo' ),
                'default'   => 'Email:',
                'required' => array( 'contact_email-enable', '=', true )
            ),
            array(
                'id'        => 'contact-email-address',
                'type'      => 'text',
                'title'     => __( 'Email Address', 'redux-framework-demo' ),
                'default'   => 'XS@yoursite.com',
                'required' => array( 'contact_email-enable', '=', true )
            ),
        )
    ) );