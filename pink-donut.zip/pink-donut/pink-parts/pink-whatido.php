<?php
    global $pink;
    $whatido_header = $pink['whatido-header-text'];
    $whatido_header_right = $pink['whatido-head_title_rigth'];
?>


        <section id="whatido" class="whatido">
            <div class="container">
                <div class="row">
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="head_title text-center wow fadeInLeft"  data-wow-duration="3s">
							<h2><?php echo $whatido_header; ?></h2>
							<div class="separator"></div>
						</div>
					</div>
					
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="head_title_rigth wow fadeInRight"  data-wow-duration="3s">
							<p><?php echo $whatido_header_right; ?></p>
						</div>
					</div><!-- End of col-sm-5 -->
                    <div class="main_whatido_content text-center">

		            	<?php if (isset($pink['main_whatido_content']) && !empty($pink['main_whatido_content'])) {
		            		foreach ($pink['main_whatido_content'] as $single_whatido) {
		            	?>
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single_whatido wow fadeInDown"  data-wow-duration="1s">
								<div class="single_whatido_img">
									<img src="<?php echo $single_whatido['image']; ?>" alt="<?php echo $single_whatido['title'].'Image'; ?>" />
								</div>
								<h3><?php echo $single_whatido['title']; ?></h3>
								<p><?php echo $single_whatido['description']; ?></p>
							</div>
						</div>
						<?php } } else { ?>

						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single_whatido wow fadeInDown"  data-wow-duration="1s">
								<div class="single_whatido_img">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/what1.png" alt="" />
								</div>
								<h3>ultricies</h3>
								<p>Four dollar toast messenger bag green juice, organic cliche tofu synth small batch locavore austin. Squid mlkshk authe ntic pinterest, pour-over gastropub XOXO seitan sartorial humblebrag. </p>
							</div>
						</div>
						
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single_whatido wow fadeInDown"  data-wow-duration="3s">
								<div class="single_whatido_img">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/what2.png" alt="" />
								</div>
								<h3>porttitor</h3>
								<p>Four dollar toast messenger bag green juice, organic cliche tofu synth small batch locavore austin. Squid mlkshk authe ntic pinterest, pour-over gastropub XOXO seitan sartorial humblebrag. </p>
							</div>
						</div>
						
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single_whatido wow fadeInDown"  data-wow-duration="4s">
								<div class="single_whatido_img">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/what3.png" alt="" />
								</div>
								<h3>Curabitur</h3>
								<p>Four dollar toast messenger bag green juice, organic cliche tofu synth small batch locavore austin. Squid mlkshk authe ntic pinterest, pour-over gastropub XOXO seitan sartorial humblebrag. </p>
							</div>
						</div>
						<?php } ?>
                    </div>
                </div>
            </div>
        </section><!-- End of Features Section -->
