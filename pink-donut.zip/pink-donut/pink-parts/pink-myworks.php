<?php
    global $pink;
    $myworks_header = $pink['myworks-header-text'];
    $layout = $pink['nav-item']['enabled'];
    $showBtn = 0;
    if ($layout){
        foreach ($layout as $key=>$value) {
            switch ($key) {
                case 'about':
                    $showBtn = 1;
                    break;
            }
        }
    } else {
    	$showBtn = 0;
    }
?>

<section id="myworks" class="myworks">
    <div class="container">
        <div class="row">	
			<div class="col-md-1 col-md-offset-5 col-sm-1 col-sm-offset-5 col-xs-12 no-padding">
				<div class="scrolldownall text-right">
					<?php if ($showBtn == 1) { ?>
					<a href="#about" class="scroll_btnall"></a>
					<?php } ?>
				</div>
			</div><!-- End of col-sm-2 -->
			<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="head_title text-center wow fadeInLeft"  data-wow-duration="2s">
					<h2><?php echo $myworks_header; ?></h2>
					<div class="separator"></div>
				</div>
			</div>
			
        </div>
    </div>
	
	<div class="main_myworks_content text-center">
	    <?php
	    	if (isset($pink['myworks_image_upload']) && !empty($pink['myworks_image_upload'])) {
            	foreach ($pink['myworks_image_upload'] as $myworks_single_img) {
        ?>
		<div id="single_work_image" class="single_work_colum col-md-3 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="1.5s">
			<div class="single_work">
				<img src="<?php echo $myworks_single_img['image']; ?>" alt="<?php echo $myworks_single_img['title']; ?>" />
			</div>
		</div>
		<?php } } else { ?>

		<div class="single_work_colum col-md-3 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="1.5s">
			<div class="single_work">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/work1.jpg" alt="" />
			</div>
		</div>
		<div class="single_work_colum col-md-3 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="2s">
			<div class="single_work">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/work2.jpg" alt="" />
			</div>
		</div>
		<div class="single_work_colum col-md-3 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="3s">
			<div class="single_work">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/work3.jpg" alt="" />
			</div>
		</div>
		<div class="single_work_colum col-md-3 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="4s">
			<div class="single_work">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/work4.jpg" alt="" />
			</div>
		</div>
		<?php } ?>
	</div>
</section>
