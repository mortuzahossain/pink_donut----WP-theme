<?php
    global $pink;
    $layout = $pink['nav-item']['enabled'];
    $slideItemNumber = 0;
?>

<section id="home" class="home">
    <div class="home_overlay">
        <div class="container">
            <div class="row">
				
				<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				  <!-- Indicators -->
				  <ol class="carousel-indicators">
				    <?php if (isset($pink['home-slider']) && !empty($pink['home-slider'])) { foreach ($pink['home-slider'] as $single_slider_item) { ?>
						<li data-target="#carousel-example-generic" data-slide-to="<?php echo $slideItemNumber; ?>" <?php if($slideItemNumber == '0'){echo 'class="active"';} ?>></li>
				    <?php $slideItemNumber = $slideItemNumber+1;}} else { ?>
						<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
						<li data-target="#carousel-example-generic" data-slide-to="1"></li>
						<li data-target="#carousel-example-generic" data-slide-to="2"></li>
					<?php } ?>
				  </ol>
				  <!-- Wrapper for slides -->
				<div class="carousel-inner" role="listbox">

					<?php if (isset($pink['home-slider']) && !empty($pink['home-slider'])) {$slideItemNumber = 0; foreach ($pink['home-slider'] as $single_slider_item) { ?>
					<div class="item <?php if($slideItemNumber == '0'){echo 'active';} ?>">
						 <div class="carousel-caption">
							<p><?php echo $single_slider_item['title']; ?></p>
							<div class="btn_bg">
								<a href="<?php echo $single_slider_item['url']; ?>" class="btn "><?php echo $single_slider_item['description']; ?></a>
							</div>
						</div>
						<img src="<?php echo $single_slider_item['image']; ?>" alt="...">
					</div>
					<?php $slideItemNumber = $slideItemNumber+1;}} else { ?>

					<div class="item active">
						 <div class="carousel-caption">
							<p>Tacos cardigan truffaut Quanted!</p>
							<div class="btn_bg">
								<a href="" class="btn ">SEE MORE</a>
							</div>
						</div>
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/slider.jpg" alt="...">
					</div>

					<div class="item">
						<div class="carousel-caption">
							<p>Tacos cardigan truffaut Quanted!</p>
							<div class="btn_bg">
								<a href="" class="btn ">SEE MORE</a>
							</div>
						</div>
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/slider.jpg" alt="...">
					</div>
					<div class="item">
						<div class="carousel-caption">
							<p>Tacos cardigan truffaut Quanted!</p>
							<div class="btn_bg">
								<a href="" class="btn ">SEE MORE</a>
							</div>
						</div>
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/slider.jpg" alt="...">
					</div>

					<?php } ?>
				</div>

				</div>

				<?php
				    if ($layout){
				        foreach ($layout as $key=>$value) {
				            switch ($key) {
				                case 'whatido':
				                    echo '<div class="scrolldown">
											<a href="#whatido" class="scroll_btn"></a>
										</div>';
				                    break;
				            }
				        }
				    } else {
				        ?>
				        <div class="scrolldown">
							<a href="#whatido" class="scroll_btn"></a>
						</div>
				        <?php
				    }
				?>
            </div>
        </div>
    </div>
</section>