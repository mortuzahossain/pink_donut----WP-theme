<?php
    global $pink;
    $contact_header = $pink['contact-header-text'];
	
	$contact_address_header = "";
	$contact_address_editor = "";
	$contact_phone_header = "";
	$contact_phone_number = "";
	$contact_email_header = "";
	$contact_email_address = "";

    $contact_address_enable = $pink['contact_adress-enable'];
    if($contact_address_enable){
	    $contact_address_header = $pink['contact-address-header'];
	    $contact_address_editor = $pink['contact-editor-text'];
    }
    
    $contact_phone_enable = $pink['contact_phone-enable'];
    if($contact_phone_enable){
	    $contact_phone_header = $pink['contact-phone-header'];
	    $contact_phone_number = $pink['contact-phone-number'];
    }

    $contact_email_enable = $pink['contact_email-enable'];
    if($contact_email_enable){
	    $contact_email_header = $pink['contact-email-header'];
	    $contact_email_address = $pink['contact-email-address'];
	}

?>

<section id="contact" class="contact">
    <div class="container">
        <div class="row">
            <div class="main_contact">
                
                <div class="contact_content">
                    
                    <div class="col-md-6 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="2s">
						<div class="contact_message">

							<form action="" id="formid" method="post">
								<label for="">Name</label>
								<div class="form-group">
									<input type="text" class="form-control" name="name" placeholder="name" required="">
								</div>
								
								<label for="">Email</label>
								<div class="form-group">
									<input type="email" class="form-control" name="email" placeholder="Email" required="">
								</div>

								<label for="">Message</label>
								<div class="form-group">
									<textarea class="form-control" name="message" rows="8" placeholder="Message"></textarea>
								</div>

								<div class="message_btn text-center">
									<div class="btn_bg">
										<input class="btn" type="submit" value="Send">
									</div>
								</div>
							</form>
							
						</div>
					</div>




                    <div class="col-md-6 col-sm-6 col-xs-12 wow fadeInRight"  data-wow-duration="2s">
						<div class="contact_socail_bookmark_area">
							<div class="head_title text-center">
								<h2><?php echo $contact_header; ?></h2>
								<div class="separator"></div>
							</div>
							
							
							<div class="contact_socail_bookmark">
			            	<?php if (isset($pink['contact-social-icon']) && !empty($pink['contact-social-icon'])) {
			            		foreach ($pink['contact-social-icon'] as $single_social_item) {
			            	?>
								<a href="<?php echo $single_social_item['title']; ?>"><img src="<?php echo $single_social_item['thumb']; ?>" alt="<?php echo $single_social_item['title']; ?>" /></a>
							<?php } } else { ?>
								<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/fb.png" alt="" /></a>
								<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/fb.png" alt="" /></a>
								<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/fb.png" alt="" /></a>
								<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/fb.png" alt="" /></a>
							<?php } ?>
							</div>
							
							<div class="contact_adress">
							<?php if($contact_address_enable){ ?>
								<h3><?php echo $contact_address_header; ?></h3>
								<span><?php echo $contact_address_editor; ?></span>
							<?php } else { ?>
								<h3>Address:</h3>
								<span>9114 Bridge Street ,</span>
								<span>Hillsboro, OR 97124</span>
							<?php } ?>
							</div>
							
							<div class="row">

								<div class="col-md-6 col-sm-6 col-xs-12">
									<div class="single_contact_phone">
									<?php if($contact_phone_enable){ ?>
										<h3><?php echo $contact_phone_header; ?></h3>
										<span><?php echo $contact_phone_number; ?></span>
									<?php } else { ?>
										<h3>Phone:</h3>
										<span>+48 202 - 555 - 0114</span>
									<?php } ?>
									</div>
								</div>
								
								<div class="col-md-6 col-sm-6 col-xs-12">
									<div class="single_contact_phone">
									<?php  if($contact_email_enable){ ?>
										<h3><?php echo $contact_email_header; ?></h3>
										<span><?php echo $contact_email_address; ?></span>
									<?php } else { ?>
										<h3>Email:</h3>
										<span>XS@yoursite.com</span>
									<?php } ?>
									</div>
								</div>

							</div>
							
						</div>
					</div>
                </div>
            </div>
        </div>
		
    </div>
</section><!-- End of contact With Map Section -->

<!-- // For Email -->

<?php
if ($_SERVER['REQUEST_METHOD'] == "POST") {

	$name 		= $_POST['name'];
	$email 		= $_POST['email'];
	$message 	= $_POST['message'];

	$to = $pink['admin-email'];

	$admin_subject = "Message From ".get_option( 'blogname' );
	$admin_message = $name."\n\n".$email."\n\n".$message;

	$user_back_subject = "Thanks From ".get_option( 'blogname' );
	$user_back_message = "I Got Your Feedback Thanks. I will replay Back to you if i fell necessary.";

	if (mail($to, $admin_subject, $admin_message)) {
		mail($email, $user_back_subject, $user_back_message);
		echo "<p class='text-center success-message'><strong>Your massage has been send.</strong></p>";
	} else {
		echo "<p class='text-center error-message'><strong>Sorry Please Try Again.</strong></p>";
	}

}

?>


