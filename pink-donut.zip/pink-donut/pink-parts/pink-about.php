<?php
    global $pink;
    $about_header = $pink['about-header-text'];
    $about_head_title_rigth = $pink['about-head_title_rigth'];

?>

<section id="about" class="about">
    <div class="container">
        <div class="row">
			<div class="col-md-6 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="2s">
				<div class="head_title text-center">
					<h2><?php echo $about_header; ?></h2>
					<div class="separator"></div>
				</div>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 wow fadeInRight"  data-wow-duration="2s">
				<div class="head_title_rigth">
					<p><?php echo $about_head_title_rigth; ?></p>
				</div>
			</div>

			

            <div class="main_about_content text-center">

            	<?php if (isset($pink['main_about_content']) && !empty($pink['main_about_content'])) {
            		foreach ($pink['main_about_content'] as $single_content) {
            	?>

                <div class="col-md-4 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="1.5s">
					<div class="single_about">
						<div class="single_about_img">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/skil1.png" alt="" />
						</div>
						<h3><span class="statistic-counter"><?php echo $single_content['url'] ?></span><?php echo $single_content['title'] ?></h3>
						<p><?php echo $single_content['description'] ?></p>
					</div>
				</div>

				<?php } } else { ?>

                <div class="col-md-4 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="1.5s">
					<div class="single_about">
						<div class="single_about_img">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/skil1.png" alt="" />
						</div>
						<h3><span class="statistic-counter">30.25</span>Curabitur</h3>
						<p>Four dollar toast messenger bag green juice, organic cliche tofu synth small batch locavore austin. Squid mlkshk authe ntic pinterest, pour-over gastropub XOXO seitan sartorial humblebrag. </p>
					</div>
				</div>				 
                <div class="col-md-4 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="2s">
					<div class="single_about">
						<div class="single_about_img">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/skil1.png" alt="" />
						</div>
						<h3><span class="statistic-counter">20.75</span>spanCurabitur</h3>
						<p>Four dollar toast messenger bag green juice, organic cliche tofu synth small batch locavore austin. Squid mlkshk authe ntic pinterest, pour-over gastropub XOXO seitan sartorial humblebrag. </p>
					</div>
				</div>
				
                <div class="col-md-4 col-sm-6 col-xs-12 wow fadeInLeft"  data-wow-duration="3s">
					<div class="single_about">
						<div class="single_about_img">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/skil1.png" alt="" />
						</div>
						<h3><span class="statistic-counter">15.20</span>Curabitur</h3>
						<p>Four dollar toast messenger bag green juice, organic cliche tofu synth small batch locavore austin. Squid mlkshk authe ntic pinterest, pour-over gastropub XOXO seitan sartorial humblebrag. </p>
					</div>
				</div>
				<?php } ?>

            </div>
        </div>
    </div>
</section>
