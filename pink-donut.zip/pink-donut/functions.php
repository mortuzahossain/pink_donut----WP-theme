<?php
// Including Theme Style And JS
if (file_exists( dirname( __FILE__ ) . '/inc/pink-style-js.php' )) {
	require_once( get_template_directory() .'/inc/pink-style-js.php'  );
}
// Redux fremwork 
if ( !class_exists( 'ReduxFramework' ) && file_exists( dirname( __FILE__ ) . '/inc/redux-framework/ReduxCore/framework.php' ) ) {
	require_once( dirname( __FILE__ ) . '/inc/redux-framework/ReduxCore/framework.php' );
}
if ( !isset( $redux_demo ) && file_exists( dirname( __FILE__ ) . '/inc/redux-framework/sample/sample-config.php' ) ) {
	require_once( dirname( __FILE__ ) . '/inc/pink-options.php' );
}
// Removing Redux Framework From tools .The value must be over 10
add_action( 'admin_menu', 'remove_redux_menu',12 );
	function remove_redux_menu() {
	remove_submenu_page('tools.php','redux-about');
}

?>