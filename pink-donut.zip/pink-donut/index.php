<?php
	global $pink;
	$layout = $pink['nav-item']['enabled'];

	get_header();
	get_template_part( 'pink-parts/pink', 'headerslider' );

    if ($layout){
        foreach ($layout as $key=>$value) {
            switch ($key) {
                case 'about':
                    get_template_part( 'pink-parts/pink', 'about' );
                    break;
                case 'myworks':
                    get_template_part( 'pink-parts/pink', 'myworks' );
                    break;
                case 'whatido':
                    get_template_part( 'pink-parts/pink', 'whatido' );
                    break;
                case 'contact':
                    get_template_part( 'pink-parts/pink', 'contact' );
                    break;
            }
        }
    } else {
		get_template_part( 'pink-parts/pink', 'whatido' );
		get_template_part( 'pink-parts/pink', 'myworks' );
		get_template_part( 'pink-parts/pink', 'about' );
		get_template_part( 'pink-parts/pink', 'contact' );
    }

?>




<?php get_footer(); ?>