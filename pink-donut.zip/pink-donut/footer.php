<?php
	global $pink;
	$layout = $pink['nav-item']['enabled'];
    $footer_text = $pink['copyright-text'];
?>


        <section class="contact contact-footer">
            <div class="container">
				<div class="row">
					<div class="footer_copyright">
					
						<div class="col-md-6 col-sm-6 col-xs-12 wow fadeInDown"  data-wow-duration="3s">
							<div class="single_copyirgth text-left">
								<p><?php echo $footer_text; ?></p>
							</div>
						</div>
						
						<div class="col-md-6 col-sm-6 col-xs-12">
							<div class="single_copyirgth wow fadeInUp"  data-wow-duration="2s">
								<ul class="navbar-right">

                                    <?php
                                        if ($layout){
                                            echo '<li class="active"><a href="#home">Home</a></li>';
                                            foreach ($layout as $key=>$value) {
                                                switch ($key) {
                                                    case 'about':
                                                        echo '<li><a href="#about">About</a></li>';
                                                        break;
                                                    case 'myworks':
                                                        echo '<li><a href="#myworks">My works</a></li>';
                                                        break;
                                                    case 'whatido':
                                                        echo '<li><a href="#whatido">What i do</a></li>';
                                                        break;
                                                    case 'contact':
                                                        echo '<li><a href="#contact">Contact</a></li>';
                                                        break;
                                                }
                                            }
                                        } else {
                                            ?>
												<li class="active"><a href="#home">Home</a></li>
												<li><a href="#whatido">What i do</a></li>
												<li><a href="#myworks">My works</a></li>
												<li><a href="#about">About</a></li>
												<li><a href="#contact">Contact</a></li>
                                            <?php
                                        }
                                    ?>


								
								</ul>
							</div>
						</div>
						
					</div>
				</div>
            </div>
        </section><!-- End of contact With Map Section -->

        <!-- STRAT SCROLL TO TOP -->

        <div class="scrollup">
            <a href="#"><i class="fa fa-chevron-up"></i></a>
        </div>

        <?php wp_footer(); ?>
        
    </body>
</html>
