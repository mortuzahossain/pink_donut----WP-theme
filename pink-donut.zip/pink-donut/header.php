<?php
    global $pink;
    $layout = $pink['nav-item']['enabled'];
?>


<!doctype html>
<html class="no-js" lang="<?php bloginfo( 'language' ); ?>">
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php bloginfo( 'title' ); ?></title>
        <meta name="description" content="<?php bloginfo( 'description' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="<?php if($pink['upload-facivon'] == '1' && !empty($pink['favicon'])){echo $pink['favicon']['url']; }else{echo get_template_directory_uri().'/favicon.ico';} ?>" type="image/x-icon"/>
	
		<?php wp_head(); ?>
    </head>

    <body <?php body_class( '' ); ?>>

		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        
        <!--Home page style-->
        <header id="main_menu" class="header">
            <div class="main_menu_bg navbar-fixed-top">
                <div class="container">
                    <div class="row">
                        <div class="nave_menu">
                            <nav class="navbar navbar-default">
                                <div class="container-fluid">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                            <span class="sr-only">Toggle navigation</span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>
                                        
                                    </div>
                                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                                        <ul class="nav navbar-nav">
                                            <?php
                                                if ($layout){
                                                    echo '<li><a href="#home">Home</a></li>';
                                                    foreach ($layout as $key=>$value) {
                                                        switch ($key) {
                                                            case 'about':
                                                                echo '<li><a href="#about">About</a></li>';
                                                                break;
                                                            case 'myworks':
                                                                echo '<li><a href="#myworks">My works</a></li>';
                                                                break;
                                                            case 'whatido':
                                                                echo '<li><a href="#whatido">What i do</a></li>';
                                                                break;
                                                            case 'contact':
                                                                echo '<li><a href="#contact">Contact</a></li>';
                                                                break;
                                                        }
                                                    }
                                                } else {
                                                    ?>
                                                    <li><a href="#home">Home</a></li>
                                                    <li><a href="#whatido">What i do</a></li>
                                                    <li><a href="#myworks">My works</a></li>
                                                    <li><a href="#about">About</a></li>
                                                    <li><a href="#contact">Contact</a></li>
                                                    <?php
                                                }
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                            </nav>
                        </div>	
                    </div>

                </div>

            </div>
        </header>